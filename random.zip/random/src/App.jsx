import React, { useState } from "react";
import "./App.css";
const App = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [data, setData] = useState([]);
  
  const fetchData = async () => {
    try {
      const response = await fetch(
        `https://api.unsplash.com/search/photos?client_id=nS0ZuWjRPItGjKojIhTKZfQi5O92kbah4bbgZY2Z2LU&page=1&query=${searchTerm}`
      );
      const jsonData = await response.json();
      setData(jsonData.results);
    } catch (error) {
      console.error(error);
    }
  };

  const handleSearch = () => {
    fetchData();
  };
  const handleDarkModeChange = () => {
    const htmlElement = document.querySelector("html");
    htmlElement.dataset.theme = htmlElement.dataset.theme === "dark" ? "retro" : "dark";
  };

  const [isClicked, setIsClicked] = useState(false);
  const handleClick = () => {
    setIsClicked(!isClicked);
  };
  const itemClass = isClicked ? "desp clicked" : "desp";

  return (
    <div className="apps">
      <div className="header container  mt-8  rounded-2xl ">
        <div className="flex   gap-4">
          <input
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            type="text"
            placeholder="Type here"
            className="input rounded-2xl  input-error w-full max-w-xs"
          />
          <button onClick={handleSearch} className="btn btn-neutral">
            Button
          </button>
        </div>
        <div className="flex mode right-8">
          <input
            onChange={handleDarkModeChange}
            type="checkbox"
            className="toggle"
          />
        </div>
      </div>
      <hr />
      <div className="container box rounded-3xl ">
        {data.map((item) => (
          <div
            className="desp"
            key={item.id}
            onClick={() => handleItemClick(item)}
          >
            <img
              className="imgs"
              src={item.urls.small}
              alt={item.alt_description}
            />
            <h1 className="font-bold bg-slate-600  text-white">
              {item.user.name}
            </h1>
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;
